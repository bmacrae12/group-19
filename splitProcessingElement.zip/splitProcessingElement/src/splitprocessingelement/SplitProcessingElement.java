/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package splitprocessingelement;

/**
 *
 * @author richa
 */
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class SplitProcessingElement {
    private List<File> inputEntries;
    private int linesPerPart;

    public SplitProcessingElement(List<File> inputEntries, int linesPerPart) {
        this.inputEntries = inputEntries;
        this.linesPerPart = linesPerPart;
    }

    public List<File> process() throws IOException {
        List<File> outputEntries = new ArrayList<>();
        for (File entry : inputEntries) {
            if (entry.isFile()) {
                String baseName = entry.getName().replaceAll("\\..*", "");
                String extension = entry.getName().replaceAll("^.*\\.", "");
                try (BufferedReader reader = new BufferedReader(new FileReader(entry))) {
                    int partNum = 1;
                    String line;
                    List<String> lines = new ArrayList<>();
                    while ((line = reader.readLine()) != null) {
                        lines.add(line);
                        if (lines.size() >= linesPerPart) {
                            String partName = String.format("%s.part%d.%s", baseName, partNum++, extension);
                            File partFile = new File(entry.getParent(), partName);
                            writeLinesToFile(partFile, lines);
                            outputEntries.add(partFile);
                            lines.clear();
                        }
                    }
                    if (!lines.isEmpty()) {
                        String partName = String.format("%s.part%d.%s", baseName, partNum, extension);
                        File partFile = new File(entry.getParent(), partName);
                        writeLinesToFile(partFile, lines);
                        outputEntries.add(partFile);
                    }
                }
            }
        }
        return outputEntries;
    }

    private void writeLinesToFile(File file, List<String> lines) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
        }
    }
}
    

